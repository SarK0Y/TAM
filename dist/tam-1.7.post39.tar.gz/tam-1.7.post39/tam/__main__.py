from tam import _tam
